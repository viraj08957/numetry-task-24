import React, { useState } from "react";
import "./Chatbot.css";

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (input.trim()) {
      const userMessage = { text: input, user: "human" };
      setMessages([...messages, userMessage]);
      respondToMessage(input);
      setInput("");
    }
  };

  const respondToMessage = (message) => {
    let botResponse = "Sorry, I did not understand that.";

    if (
      message.toLowerCase().includes("hii") ||
      message.toLowerCase().includes("hello") ||
      message.toLowerCase().includes("hi")
    ) {
      botResponse = "hey there! i am numBOT how i can help you ?";
    } else if (message.toLowerCase().includes("tell me about company")) {
      botResponse =
        "With a passion for technology and a commitment to excellence, we combine creativity with technical expertise to deliver unparalleled solutions tailored to your unique needs. Founded in 2011, we'e built a reputation for delivering results that exceed expectations, thanks to our collaborative approach, attention to detail, and dedication to client satisfaction.";
    } else if (
      message.toLowerCase().includes("what kind of services you provide") ||
      message.toLowerCase().includes("services")
    ) {
      botResponse =
        "1.Web-developement 2.Motion Graphics for web 3.DevOps 4.Cloud Migration 5.Mobile app Developement";
    } else if (message.toLowerCase().includes("contact")) {
      botResponse =
        "You can contact us at (123) 456-7890 or email us at contact@numetryTechnoloyies.com.";
    } else if (message.toLowerCase().includes("admission")) {
      botResponse =
        "The admission process involves filling out an application form, submitting necessary documents, and attending an interview. Visit our admissions page for more details.";
    } else if (message.toLowerCase().includes("events")) {
      botResponse =
        "The school hosts a variety of events throughout the year, including sports day, science fair, and cultural fest. Check our events calendar on the website for upcoming events.";
    } else if (message.toLowerCase().includes("timings")) {
      botResponse =
        "The school operates from 8:00 AM to 3:00 PM, Monday to Friday.";
    } else if (message.toLowerCase().includes("subjects")) {
      botResponse =
        "We offer a wide range of subjects including Mathematics, Science, English, History, Geography, and Physical Education. Visit our curriculum page for more information.";
    }

    setTimeout(() => {
      setMessages((prevMessages) => [
        ...prevMessages,
        { text: botResponse, user: "bot" },
      ]);
    }, 500);
  };

  return (
    <div className="chatbot-wrapper">
      <div className="chatbot">
        <div className="chat-window">
          {messages.map((msg, index) => (
            <div key={index} className={`message ${msg.user}`}>
              {msg.text}
            </div>
          ))}
        </div>
        <div className="input-area">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSend()}
          />
          <button onClick={handleSend}>Send</button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;
